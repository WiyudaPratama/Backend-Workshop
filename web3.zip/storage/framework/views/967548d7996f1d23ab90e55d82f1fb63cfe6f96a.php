<?php $__env->startSection('title', 'Peserta Workshop BPC'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-12 col-lg-6">
    <h1 class="h3 mb-4 text-gray-800">Daftar Peserta</h1>
  </div>
  <div class="col-12 col-lg-6">
    <?php if(session('alert')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('alert')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endif; ?>
  </div>
</div>
<div class="row">
  <div class="col-12">
    <table class="table table-striped table-bordered" style="width: 100%" id="daftarPeserta">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama</th>
          <th>NPM</th>
          <th>Email</th>
          <th>No WhatsApp</th>
          <th>Status</th>
          <th>Bukti Pembayaran</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php
          $i = 1;
        ?>
        <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th><?php echo e($i++); ?></th>
            <td><?php echo e($participant->nama); ?></td>
            <td><?php echo e($participant->npm); ?></td>
            <td><?php echo e($participant->email); ?></td>
            <td><?php echo e($participant->nohp); ?></td>
            <td><?php echo e($participant->status); ?></td>
            <td>
              <a class="fancybox" rel="group" href="<?php echo e(url('/storage/image', $participant->image)); ?>"><img src="<?php echo e(url('/storage/image', $participant->image)); ?>" alt=""  width="200px"/></a>
            </td>
            <td>
              <form action="<?php echo e(route('peserta.update', $participant->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <button type="submit" class="btn btn-success"><i class="fas fa-check"></i></button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/backend-workshop/resources/views/admin/peserta.blade.php ENDPATH**/ ?>